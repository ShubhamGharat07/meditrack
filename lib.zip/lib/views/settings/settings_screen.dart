import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_text_style.dart';
import '../../core/utils/responsive_helper.dart';
import '../../providers/theme_provider.dart';
import '../../routes/app_routes.dart';
import '../../widgets/common/custom_card.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final r = ResponsiveHelper(context);
    final themeProvider = context.watch<ThemeProvider>();

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: r.pagePadding,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: r.mediumSpace),

              // Header
              Row(
                children: [
                  IconButton(
                    onPressed: () => context.go(AppRoutes.profile),
                    icon: const Icon(Icons.arrow_back_ios),
                    padding: EdgeInsets.zero,
                  ),
                  SizedBox(width: r.wp(2)),
                  Text('Settings', style: AppTextStyles.heading2),
                ],
              ),

              SizedBox(height: r.largeSpace),

              // Appearance
              Text('Appearance', style: AppTextStyles.heading3),
              SizedBox(height: r.mediumSpace),
              CustomCard(
                child: Row(
                  children: [
                    Container(
                      padding: EdgeInsets.all(r.wp(2)),
                      decoration: BoxDecoration(
                        color: AppColors.primary.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(r.smallRadius),
                      ),
                      child: Icon(
                        themeProvider.isDarkMode
                            ? Icons.dark_mode
                            : Icons.light_mode,
                        color: AppColors.primary,
                        size: r.smallIcon,
                      ),
                    ),
                    SizedBox(width: r.wp(3)),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Dark Mode',
                            style: AppTextStyles.bodyMedium.copyWith(
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          Text(
                            themeProvider.isDarkMode
                                ? 'Dark theme is on'
                                : 'Light theme is on',
                            style: AppTextStyles.bodySmall,
                          ),
                        ],
                      ),
                    ),
                    Switch(
                      value: themeProvider.isDarkMode,
                      onChanged: (_) => themeProvider.toggleTheme(),
                      activeColor: AppColors.primary,
                    ),
                  ],
                ),
              ),

              SizedBox(height: r.largeSpace),

              // Notifications
              Text('Notifications', style: AppTextStyles.heading3),
              SizedBox(height: r.mediumSpace),
              CustomCard(
                child: Column(
                  children: [
                    _buildSettingRow(
                      r,
                      icon: Icons.notifications_outlined,
                      iconColor: AppColors.secondary,
                      title: 'Medicine Reminders',
                      subtitle: 'Get notified for medicines',
                      trailing: Switch(
                        value: true,
                        onChanged: (_) {},
                        activeColor: AppColors.primary,
                      ),
                    ),
                    Divider(
                      height: 1,
                      color: const Color(0xFF9E9EAA).withOpacity(0.1),
                    ),
                    _buildSettingRow(
                      r,
                      icon: Icons.calendar_month_outlined,
                      iconColor: AppColors.success,
                      title: 'Appointment Reminders',
                      subtitle: 'Get notified for appointments',
                      trailing: Switch(
                        value: true,
                        onChanged: (_) {},
                        activeColor: AppColors.primary,
                      ),
                    ),
                  ],
                ),
              ),

              SizedBox(height: r.largeSpace),

              // Data
              Text('Data', style: AppTextStyles.heading3),
              SizedBox(height: r.mediumSpace),
              CustomCard(
                child: Column(
                  children: [
                    _buildSettingRow(
                      r,
                      icon: Icons.sync,
                      iconColor: AppColors.primary,
                      title: 'Auto Sync',
                      subtitle: 'Sync data with cloud',
                      trailing: Switch(
                        value: true,
                        onChanged: (_) {},
                        activeColor: AppColors.primary,
                      ),
                    ),
                    Divider(
                      height: 1,
                      color: const Color(0xFF9E9EAA).withOpacity(0.1),
                    ),
                    _buildSettingRow(
                      r,
                      icon: Icons.storage_outlined,
                      iconColor: AppColors.warning,
                      title: 'Clear Cache',
                      subtitle: 'Clear local stored data',
                      trailing: Icon(
                        Icons.arrow_forward_ios,
                        size: r.wp(3.5),
                        color: const Color(0xFF9E9EAA),
                      ),
                      onTap: () => _showClearCacheDialog(context),
                    ),
                  ],
                ),
              ),

              SizedBox(height: r.largeSpace),

              // About
              Text('About', style: AppTextStyles.heading3),
              SizedBox(height: r.mediumSpace),
              CustomCard(
                child: Column(
                  children: [
                    _buildSettingRow(
                      r,
                      icon: Icons.info_outline,
                      iconColor: AppColors.secondary,
                      title: 'App Version',
                      subtitle: 'MediTrack v1.0.0',
                      trailing: const SizedBox(),
                    ),
                    Divider(
                      height: 1,
                      color: const Color(0xFF9E9EAA).withOpacity(0.1),
                    ),
                    _buildSettingRow(
                      r,
                      icon: Icons.privacy_tip_outlined,
                      iconColor: AppColors.success,
                      title: 'Privacy Policy',
                      subtitle: 'Read our privacy policy',
                      trailing: Icon(
                        Icons.arrow_forward_ios,
                        size: r.wp(3.5),
                        color: const Color(0xFF9E9EAA),
                      ),
                      onTap: () {},
                    ),
                    Divider(
                      height: 1,
                      color: const Color(0xFF9E9EAA).withOpacity(0.1),
                    ),
                    _buildSettingRow(
                      r,
                      icon: Icons.description_outlined,
                      iconColor: AppColors.warning,
                      title: 'Terms of Service',
                      subtitle: 'Read our terms',
                      trailing: Icon(
                        Icons.arrow_forward_ios,
                        size: r.wp(3.5),
                        color: const Color(0xFF9E9EAA),
                      ),
                      onTap: () {},
                    ),
                  ],
                ),
              ),

              SizedBox(height: r.largeSpace),
            ],
          ),
        ),
      ),
    );
  }

  // Reusable setting row
  Widget _buildSettingRow(
    ResponsiveHelper r, {
    required IconData icon,
    required Color iconColor,
    required String title,
    required String subtitle,
    required Widget trailing,
    VoidCallback? onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: r.hp(1.5)),
        child: Row(
          children: [
            Container(
              padding: EdgeInsets.all(r.wp(2)),
              decoration: BoxDecoration(
                color: iconColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(r.smallRadius),
              ),
              child: Icon(icon, color: iconColor, size: r.smallIcon),
            ),
            SizedBox(width: r.wp(3)),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: AppTextStyles.bodyMedium.copyWith(
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Text(subtitle, style: AppTextStyles.bodySmall),
                ],
              ),
            ),
            trailing,
          ],
        ),
      ),
    );
  }

  // Clear cache dialog
  void _showClearCacheDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Clear Cache', style: AppTextStyles.heading3),
        content: Text(
          'This will clear all locally stored data. Cloud data will not be affected.',
          style: AppTextStyles.bodyMedium,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: AppTextStyles.bodyMedium.copyWith(
                color: const Color(0xFF9E9EAA),
              ),
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Cache cleared!'),
                  backgroundColor: AppColors.success,
                ),
              );
            },
            child: Text(
              'Clear',
              style: AppTextStyles.bodyMedium.copyWith(
                color: AppColors.error,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
